#!/bin/bash

# path of the folder where source code is 
SERVICE_PATH="/RawDataService"

# source code file to execute
SOURCE="raw_data.py"

# path of the source code file
SOURCE_PATH="$SERVICE_PATH/$SOURCE"

# run the file
sudo python3 $SOURCE_PATH >/dev/null 2>&1 &

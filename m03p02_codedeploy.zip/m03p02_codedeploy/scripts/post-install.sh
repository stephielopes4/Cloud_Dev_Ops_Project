#!/bin/bash

# this script uses enviornment variables which are available for hooks

# CodeDeploy Agent needs to access the current deployment, where the deployment package and appspec.yml files are.
# it constructs the correct directory path(HOME_PATH) into the source code base
HOME_PATH="/opt/codedeploy-agent/deployment-root"
SUFFIX="deployment-archive"

# The service folder containes the source code (raw_data.py)
SERVICE="service"

# path of the folder where source code will be copied
SERVICE_PATH="/RawDataService"

# DEPLOYMENT_ID and DEPLOYMENT_GROUP_ID are the ID's CodeDeploy has assigned to the current deployment and current deployment group
# LOCAL_PREFIX gives the entire path for the configuration
LOCAL_PREFIX="$HOME_PATH/$DEPLOYMENT_GROUP_ID/$DEPLOYMENT_ID/$SUFFIX"

# code deploy agent accesses the folder for the source code through CODE_PATH
CODE_PATH="$LOCAL_PREFIX/$SERVICE"

# source code file to execute
SOURCE_FILE="raw_data.py"

# the path to source code file
SOURCE_PATH="$CODE_PATH/$SOURCE_FILE"

# m03p02_codedeploy.zip is a zip package(archive file) which contains source code folder(service), scripts folder and appspec.yml file
APPLICATION_REVISION="m03p02_codedeploy.zip"

# the path to aaplication revision(archive file)
APPLICATION_REVISION_PATH="$HOME_PATH/$DEPLOYMENT_GROUP_ID/$DEPLOYMENT_ID/$SUFFIX/$APPLICATION_REVISION"

# code deploy agent creates a global /RawDataService folder in the / (root) directory if it does not exist and
# Copies the python source code(raw_data.py) to this global folder
if [ ! -d "/RawDataService" ]
then
	sudo mkdir /RawDataService
fi

sudo pwd
sudo unzip -o $APPLICATION_REVISION_PATH -d $LOCAL_PREFIX

sudo cp  $SOURCE_PATH $SERVICE_PATH


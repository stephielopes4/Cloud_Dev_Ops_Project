#!/bin/bash

DIR="/RawDataService/"
if [ -d "$DIR" ]; then
    # Take action if $DIR exists 
	sudo rm -r /RawDataService    # remove the directory which is old application (if any) to start fresh application.

else
  # Control will jump here if $DIR does NOT exists 
    echo "The application folder not found."
    exit 1
fi

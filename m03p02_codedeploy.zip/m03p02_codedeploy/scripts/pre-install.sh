#!/bin/bash

# installing all necessary packages/modules on ec2 server(Ubuntu server)
sudo apt update -y
sudo apt install -y python3-pip python3-dev build-essential
sudo pip3 install --upgrade pip
sudo pip3 install boto3
